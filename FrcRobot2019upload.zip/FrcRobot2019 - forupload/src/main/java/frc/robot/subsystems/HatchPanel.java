/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import edu.wpi.first.wpilibj.command.Subsystem;
import frc.robot.HF2017Utility.HFPiston;

/**
 * Add your docs here.
 */
public class HatchPanel extends Subsystem {
  // Put methods for controlling this subsystem
  // here. Call these from Commands.
HFPiston OutPiston = new HFPiston(6, 7);
HFPiston UpPiston = new HFPiston(4, 5);
boolean isOutUp = false;
boolean isUpUp = false;

  @Override
  public void initDefaultCommand() {
    // Set the default command for a subsystem here.
    // setDefaultCommand(new MySpecialCommand());
  }

public void HatchToggleOut(){
  isOutUp = !isOutUp;
  if (isOutUp) {
    OutPiston.pistonOut();
  } else { 
    OutPiston.pistonIn();
  }
}
public void HatchToggleUp(){
  isUpUp = !isUpUp;
  if (isUpUp) {
    UpPiston.pistonOut();
  } else { 
    UpPiston.pistonIn();
  }
}
public void HatchUp(){
  UpPiston.pistonOut();
}
public void HatchOut(){
  OutPiston.pistonIn();
}
public void HatchIn(){
  OutPiston.pistonOut();
}
public boolean isHatchOut() {
  return isOutUp;

}

}
