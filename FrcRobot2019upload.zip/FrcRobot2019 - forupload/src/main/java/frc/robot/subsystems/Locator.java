/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

/**
 * Add your docs here.
 */

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.wpilibj.shuffleboard.Shuffleboard;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;

public class Locator {
	static final double VIEWING_ANGLE = 60 * Math.PI / 180;
	static final double DISTANCE_TO_IMAGE = 320 / Math.tan(VIEWING_ANGLE / 2);
	
	double cameraOffsetXInches = 0; //m
	int imageCenterPixel = 320; //
	double distanceSensorDistanceBack = 0;
    private int flagOnErrorValue = -4207;
	private double targetDistance = flagOnErrorValue;
	private double targetCenterX = flagOnErrorValue;
	private double targetAngle = flagOnErrorValue;
	private int readingCount = flagOnErrorValue;
	
	
	public boolean visionEnabled = true;

	NetworkTable table;
	String tableName;
//	double[] x;
//	double[] y;
//	double[] angle;
	//double[] height;
	double[] defaultValue;
	//double[] heightWidthRatio;
	int maxCountours = 20;
			
	int badReadingCount = 0;
	double[] visionData;


	public void enable(boolean setEnabled) {
		visionEnabled = setEnabled;
	}
	
	public Locator(String sourceTable, double offsetInchesFromCenterX,double distanceSensorDistanceBack) {
		tableName = sourceTable;
		table = NetworkTableInstance.getDefault().getTable(tableName);			
		cameraOffsetXInches = offsetInchesFromCenterX;
		this.distanceSensorDistanceBack = distanceSensorDistanceBack;
		reset();
	}
	
	public void reset() {
		badReadingCount = 0;
		targetDistance = flagOnErrorValue;
		targetCenterX = flagOnErrorValue;
		maxCountours = 20;
		
		//heightWidthRatio = new double[maxCountours];
	}

	
	private void updateTargetLocation() {
		final int MAX_BAD_READING=6;
		
		visionData = table.getEntry("RB lines").getDoubleArray(defaultValue);

		if(visionData != null && visionData.length == 4) {
			badReadingCount = 0;
			targetAngle = visionData[0];
			targetDistance = visionData[1];
			targetCenterX = visionData[2];
			readingCount = (int) visionData[3];
		} else {
			badReadingCount++;
			if(badReadingCount > MAX_BAD_READING) {
				targetAngle = flagOnErrorValue;
				targetDistance = flagOnErrorValue;
				targetCenterX = flagOnErrorValue;
				readingCount = 0;
			}
		}
	} 
	
	public double distanceToTarget(boolean forceUpdate)
	{
		if(forceUpdate) updateTargetLocation();
		return targetDistance;		
	}

	public double getTargetAngle(boolean forceUpdate) {
		return getTargetAngle(forceUpdate,flagOnErrorValue);
	}
	public double getTargetAngle(boolean forceUpdate, double distanceSensorReading) {
		if(forceUpdate) updateTargetLocation();
		if(targetCenterX == flagOnErrorValue) return flagOnErrorValue;
		return targetAngle;
	}
	public double getTargetAngleNext(Robot robot) {
		double angle = getTargetAngle(true,flagOnErrorValue);
		int startCount = readingCount;
		double startTime = System.currentTimeMillis();
		double maxTime = 500;
		while(robot.isEnabled() && robot.isAutonomous() && readingCount == startCount && System.currentTimeMillis() - startTime < maxTime ) {
			Timer.delay(.003);
			angle = getTargetAngle(true,flagOnErrorValue);			
		}
		return angle;
	}
	
	public void displayRawResults(){
		SmartDashboard.putString("x", "using vision table " + tableName);
		
		visionData = table.getEntry("RB spring").getDoubleArray(defaultValue);

		if(visionData != null && visionData.length == 4) {
			badReadingCount = 0;
			targetAngle = visionData[0];
			targetDistance = visionData[1];
			targetCenterX = visionData[2];
			readingCount = (int) visionData[3];
			SmartDashboard.putNumber("VisTargetAngle", targetAngle);
			SmartDashboard.putNumber("VisTargetDistance", targetDistance);
			SmartDashboard.putNumber("VisTargetCenterX", targetCenterX);
			SmartDashboard.putNumber("VisReadCount", readingCount);
		} else {
			SmartDashboard.putString("x", "vision data empty");
		}
	}
}
