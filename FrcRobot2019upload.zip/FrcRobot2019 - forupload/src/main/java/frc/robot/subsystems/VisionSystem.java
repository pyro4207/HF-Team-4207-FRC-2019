/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.command.Subsystem;
import frc.robot.OI;
import frc.robot.HF2017Utility.HFCameraPairSwitchable2019;
import frc.robot.HF2017Utility.HFCameraPairSwitchable2019b;

/**
 * Add your docs here.
 */
public class VisionSystem extends Subsystem {
  // Put methods for controlling this subsystem
  // here. Call these from Commands.
  HFCameraPairSwitchable2019b visibleCameraSet;
 //WPI_TalonSRX mLEDRing = new WPI_TalonSRX(OI.MOTOR_LEDRING);
  boolean isLEDOn = false;

    public VisionSystem(int numCamera) {
        visibleCameraSet = new HFCameraPairSwitchable2019b(numCamera);
    }

  @Override
  public void initDefaultCommand() {
    // Set the default command for a subsystem here.
    // setDefaultCommand(new MySpecialCommand());
  }

  public void toggle() {
   /* isLEDOn = !isLEDOn;
    if (isLEDOn){
      mLEDRing.set(-1);
    } else {
      mLEDRing.set(0);
    }
    */
  }
  public void turnOn() {
/*    isLEDOn = true;
      mLEDRing.set(-1);
  */  
  }
  public void turnOff() {
    //mLEDRing.set(0);
  }
  public void nextCamera() {
    visibleCameraSet.nextCamera();
  }
}
