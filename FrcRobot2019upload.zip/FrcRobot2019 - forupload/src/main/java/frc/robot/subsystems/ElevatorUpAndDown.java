/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.command.Subsystem;
import frc.robot.OI;
import frc.robot.Robot;
import frc.robot.HF2017Utility.HFMotorPair;
/**
 * Add your docs here.
 */
public class ElevatorUpAndDown extends Subsystem {
  // Put methods for controlling this subsystem
  // here. Call these from Commands.
  HFMotorPair elevator = new HFMotorPair(new WPI_TalonSRX(OI.MOTORELEVATOR), new WPI_TalonSRX(OI.MOTORELEVATOR2));
  private double directionSwitch = OI.isMonaLisa ? 1.0 : -1.0;
  

  @Override
  public void initDefaultCommand() {
    // Set the default command for a subsystem here.
    // setDefaultCommand(new MySpecialCommand());
  }
  public void elevatorUp(){
    if (Robot.m_intake.grabberLocked()) return;
    elevator.set(-1.0*directionSwitch);
  } 
  public void elevatorDown(){
    if (Robot.m_intake.isDown) return;
    elevator.set(0.4*directionSwitch);
  }
  public void stop(){
    elevator.set(0);
  }
  
}
