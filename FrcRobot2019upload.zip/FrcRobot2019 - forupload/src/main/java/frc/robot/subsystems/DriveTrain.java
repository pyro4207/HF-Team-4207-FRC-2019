/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import edu.wpi.first.wpilibj.AnalogGyro;
import edu.wpi.first.wpilibj.AnalogInput;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.PWMVictorSPX;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.OI;
import frc.robot.Robot;
import frc.robot.commands.TankDriveWithJoystick;


import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;


import frc.robot.HF2017Utility.HFMotorPair;
/**
 * The DriveTrain subsystem incorporates the sensors and actuators attached to
 * the robots chassis. These include four drive motors, a left and right encoder
 * and a gyro.
 */
public class DriveTrain extends Subsystem {
  public boolean driveBackward = false;
  private double initialAngle = 0;
  //private WPI_TalonSRX leftM1 = new WPI_TalonSRX(OI.MOTORDRIVELEFTBACK);
  private final SpeedController m_leftMotor
      = new SpeedControllerGroup(new WPI_TalonSRX(OI.MOTORDRIVELEFTBACK), new WPI_TalonSRX(OI.MOTORDRIVELEFTFRONT));
  private final SpeedController m_rightMotor
      = new SpeedControllerGroup(new WPI_TalonSRX(OI.MOTORDRIVERIGHTBACK), new WPI_TalonSRX(OI.MOTORSDRIVERIGHTFRONT));

  public final DifferentialDrive m_drive = new DifferentialDrive(m_leftMotor, m_rightMotor);
  double speedMultiplier = .9; //
  
  /**
   * Create a new drive train subsystem.
   */
  public DriveTrain() {
    super();
    
    // Encoders may measure differently in the real world and in
    // simulation. In this example the robot moves 0.042 barleycorns
    // per tick in the real world, but the simulated encoders
    // simulate 360 tick encoders. This if statement allows for the
    // real robot to handle this difference in devices.

    // Let's name the sensors on the LiveWindow
    addChild("Drive", m_drive);
  }

  /**
   * When no other command is running let the operator drive around using the
   * PS3 joystick.
   */
  @Override
  public void initDefaultCommand() {
    setDefaultCommand(new TankDriveWithJoystick());
  }

  /**
   * The log method puts interesting information to the SmartDashboard.
   */
  public void log() {

  }

  /**
   * Tank style driving for the DriveTrain.
   *
   * @param left Speed in range [-1,1]
   * @param right Speed in range [-1,1]
   */
  public void drive(double left, double right) {
    m_drive.tankDrive(left, right);
  }

  /**
   * Tank style driving for the DriveTrain.
   *
   * @param joy The ps3 style joystick to use to drive tank style.
   */
  public void drive(Joystick joy) {
  
    if(driveBackward){
      m_drive.tankDrive(speedMultiplier*joy.getRawAxis(5),speedMultiplier*joy.getRawAxis(1));
  } else {
      m_drive.tankDrive(speedMultiplier*(-1)*joy.getRawAxis(1), speedMultiplier*(-1)*joy.getRawAxis(5));
  }
  
    
    }
  public void drive(double speed) {
    System.out.println("drive" + Robot.gyro.getAngleRelativeTo(initialAngle));
   m_drive.curvatureDrive(speed,-.05*Robot.gyro.getAngleRelativeTo(initialAngle),true);    
//    	SmartDashboard.putString("distance", "" + encoderRight.getDistance());
  }
  public void setGyroAngle() {
		initialAngle = Robot.gyro.getAngle();
	}

  public void reset() {
  }
  public void stop() {
    m_drive.stopMotor();
  }

}
