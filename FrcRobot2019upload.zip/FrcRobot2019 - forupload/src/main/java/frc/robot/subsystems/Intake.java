/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.Servo;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.OI;

/**
 * Add your docs here.
 */
public class Intake extends Subsystem {
  WPI_TalonSRX intakeTilt = new WPI_TalonSRX(OI.MOTORINTAKETILT);
  WPI_TalonSRX intakeFeed = new WPI_TalonSRX(OI.MOTORINTAKEFEED);
  Servo intakeGrab = new Servo(3);
  public  double slowUpMaxSpeedInitial = OI.isMonaLisa ? .65 : .7;
  public double slowUpCurSpeed = slowUpMaxSpeedInitial;
  public double slowUpMinSpeed = .33;
  public boolean showDebug = false;
  public boolean isDown = false;
  public boolean grabberEnabled = false;
 public double lastStopTime=-10000;
 private double directionSwitch = OI.isMonaLisa ? 1.0 : -1.0;
  // Put methods for controlling this subsystem
  // here. Call these from Commands.
  public Intake() {
  intakeTilt.setNeutralMode(NeutralMode.Brake);    
    if(grabberEnabled) {
      SmartDashboard.putString("GrabStatus", "---");
    } else {
      SmartDashboard.putString("GrabStatus", "Grabber Disabled");

    }
  }
  @Override
  public void initDefaultCommand() {
  //  IntakeTilt.
    // Set the default command for a subsystem here.
    // setDefaultCommand(new MySpecialCommand());
  }
  public boolean grabberLocked() {
      if(grabberEnabled && isDown) return true;
      return false;
  }

  public void up(){
    if (grabberLocked()) return;
    intakeTilt.set(-.5*directionSwitch);
    if(showDebug) System.out.println("Moving Up");

  }

  public void slowUp() {
    if (grabberLocked()) return;
    if(System.currentTimeMillis() - lastStopTime > 500) slowUpCurSpeed = slowUpMaxSpeedInitial;
    intakeTilt.set(-slowUpCurSpeed*directionSwitch);
    if(showDebug) System.out.println("Moving Up " + slowUpCurSpeed);
    if(slowUpCurSpeed>slowUpMinSpeed) {
     // slowUpCurSpeed -= .006;
        slowUpCurSpeed = (slowUpCurSpeed*39+slowUpMinSpeed)/40;
    }
  }
  public void down(){
    if (grabberLocked()) return;
    intakeTilt.set(.2*directionSwitch);
    if(showDebug) System.out.println("Moving Down");
    slowUpCurSpeed = slowUpMaxSpeedInitial;
    
  }
  public void stop(){
    intakeTilt.set(0);
    intakeFeed.set(0);
    if(showDebug) System.out.println("Stop");
    lastStopTime = System.currentTimeMillis();    
  }
  public void in(){
    intakeFeed.set(-1.0);
  }
  public void out(){
    intakeFeed.set(.8);
  }

  private final int servoLockAngle = 110;
  private final int servoReleaseAngle = 0;
  
  public void grab() {
    if(!grabberEnabled) return;
    SmartDashboard.putString("GrabStatus", "Grabber Locked");
    intakeGrab.setAngle(servoLockAngle);
    isDown = true;
}
  public void release() {
    if(!grabberEnabled) return;
    SmartDashboard.putString("GrabStatus", "Grabber Released");
    intakeGrab.setAngle(servoReleaseAngle);
    isDown = false;
  }
  public void toggleGrabber() {
    isDown = !isDown;
      if (isDown) {
        grab();
      } else {
        release();
      }
    
  }

}

