/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.commands;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;

/**
 * This command allows PS3 joystick to drive the robot. It is always running
 * except when interrupted by another command.
 */
public class DriveWithJoystick extends Command {
	private final double minimumLeft = .1;
	private final double minimumRight = .1; 
	private final double minimumScaleLeft = .25;
	private final double minimumScaleRight = .25; 
	private double slopeLeft = (1-minimumScaleLeft)/(1-minimumLeft);
	private double slopeRight = (1-minimumScaleRight)/(1-minimumRight);
	Joystick stick;
	public DriveWithJoystick() {
		requires(Robot.m_drivetrain);
		stick = Robot.m_oi.getJoystick();

	}

	@Override
	protected void execute() {
///		Robot.m_drivetrain.tankDrive(Robot.m_oi.getJoystick());
double left = stick.getRawAxis(1);
		double right = stick.getRawAxis(5);
//		SmartDashboard.putString("joy", "L" + left + "  R" + right);				
SmartDashboard.putString("joy", "L" + slopeLeft + "  R" + slopeRight);				
SmartDashboard.putString("joy2", "L" + scaleLeft(-1.0) + "  R" + scaleRight(-1.0));	
Robot.m_drivetrain.m_drive.tankDrive(-scaleLeft(left),-scaleRight(right));

		//		Robot.m_drivetrain.tankDrive(Robot.m_oi.getJoystick());
		//SmartDashboard.putString("Direction","joystick");
	}
	public double scaleLeft(double val) {
		double sgn=1.0;
		if(val< 0) {
			sgn = -1;
			val *= -1;
		}
		if(val < minimumLeft) return 0;
		double result = sgn*(slopeLeft*(val-minimumLeft)+minimumScaleLeft);
		SmartDashboard.putNumber("left",result);
		return 	result;
	}
	public double scaleRight(double val) {
		double sgn=1.0;
		if(val< 0) {
			sgn = -1;
			val *= -1;
		}
		if(val < minimumRight) return 0;
		double result = sgn*(slopeRight*(val-minimumRight)+minimumScaleRight);
		SmartDashboard.putNumber("right", result);
		return 	result;
	}

	@Override
	protected boolean isFinished() {
		return false;
	}

	@Override
	protected void end() {
		Robot.m_drivetrain.stop();
	}
}
