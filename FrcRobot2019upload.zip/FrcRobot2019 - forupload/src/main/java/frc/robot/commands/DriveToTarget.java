
/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;


public class DriveToTarget extends Command {
  double angle;
  boolean started = false;
  
  public DriveToTarget() {
    // Use requires() here to declare subsystem dependencies
    // eg. requires(chassis);
    requires(Robot.m_drivetrain);
  }

  // Called just before this Command runs the first time
  @Override
  protected void initialize() {
    SmartDashboard.putString("Directionb","not checked");
    angle = Robot.locator.getTargetAngle(true);
    while(angle == -4207){
      angle = Robot.locator.getTargetAngle(true);
      SmartDashboard.putString("Directionb","checking");

    }
    angle = Robot.gyro.getAngle() + angle;
    SmartDashboard.putString("Directionb","at " + angle);
    started = true;
    double distancetotarget = Robot.locator.distanceToTarget(false);
    SmartDashboard.putNumber("Distance",distancetotarget);
  }

  // Called repeatedly when this Command is scheduled to run
  @Override
  protected void execute() {
    double locationangle = Robot.gyro.getAngle();
    
   

    SmartDashboard.putNumber("Aim angle", angle);
    if(angle < -4000) {
      SmartDashboard.putString("Directionc","not found b");
      Robot.m_drivetrain.m_drive.tankDrive(0,0);
      angle = Robot.locator.getTargetAngle(true) + locationangle;
    } else if(angle < locationangle){
      SmartDashboard.putString("Directionc","Turn left");
      Robot.m_drivetrain.m_drive.curvatureDrive(.45, -.1, false);
    }else{
      SmartDashboard.putString("Directionc","Turn Right");
      Robot.m_drivetrain.m_drive.curvatureDrive(.45, .1, false);
    }
  }

  // Make this return true when this Command no longer needs to run execute()
  @Override
  protected boolean isFinished() {
    double distancetotarget = Robot.locator.distanceToTarget(false);
    SmartDashboard.putNumber("Distance",distancetotarget);
    if(distancetotarget < 50 && started){
      return true;
    }
    return false;
  }

  // Called once after isFinished returns true
  @Override
  protected void end() {
    Robot.m_drivetrain.m_drive.curvatureDrive(0, 0, false);
  }

  // Called when another command which requires one or more of the same
  // subsystems is scheduled to run
  @Override
  protected void interrupted() {
    Robot.m_drivetrain.m_drive.curvatureDrive(0, 0, false);
  }
}
