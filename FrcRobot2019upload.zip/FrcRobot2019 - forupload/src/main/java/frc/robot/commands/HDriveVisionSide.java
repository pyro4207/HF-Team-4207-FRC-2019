/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Robot;

public class HDriveVisionSide extends Command {
  double m_time;
  boolean targetfound = false;
  public HDriveVisionSide(double time) {
    // Use requires() here to declare subsystem dependencies
    // eg. requires(chassis);
    m_time = time;
    
  }

  // Called just before this Command runs the first time
  @Override
  protected void initialize() {
            setTimeout(m_time/1000);


  }

  // Called repeatedly when this Command is scheduled to run
  @Override
  protected void execute() {
   
  double angle = Robot.locator.getTargetAngle(true);
  SmartDashboard.putNumber("Side Angle", angle);
  /*  if (angle > 1 ) {
      Robot.m_drivetrain.hDriveSpeed(.2);
    } else if (angle < -1 && angle >-4200) {
       Robot.m_drivetrain.hDriveSpeed(-.2);
e    } else {
      Robot.m_drivetrain.hDriveSpeed(0);
    }*/
    /*
    if(angle == -4207){
      Robot.m_drivetrain.hDriveSpeed(0);
    }else if(angle>50){
      Robot.m_drivetrain.hDriveSpeed(.7);
    }else if(angle>40){
      Robot.m_drivetrain.hDriveSpeed(.6);
    }else if(angle>30){
      Robot.m_drivetrain.hDriveSpeed(.5);
    }else if(angle>20){
      Robot.m_drivetrain.hDriveSpeed(.4);
    }else if(angle>10){
      Robot.m_drivetrain.hDriveSpeed(.3);
    }else if(angle>5){
      Robot.m_drivetrain.hDriveSpeed(.2);
    }  else if(angle<-50){
      Robot.m_drivetrain.hDriveSpeed(-.7);
    }else if(angle<-40){
      Robot.m_drivetrain.hDriveSpeed(-.6);
    }else if(angle<-30){
      Robot.m_drivetrain.hDriveSpeed(-.5);
    }else if(angle<-20){
      Robot.m_drivetrain.hDriveSpeed(-.4);
    }else if(angle<-10){
      Robot.m_drivetrain.hDriveSpeed(-.3);
    }else if(angle<-5){
      Robot.m_drivetrain.hDriveSpeed(-.2);
    }else{
      Robot.m_drivetrain.hDriveSpeed(0);
      targetfound = true;
    }*/
    //angle or time passed orrif target found
  }

  // Make this return true when this Command no longer needs to run execute()
  @Override
  protected boolean isFinished() {
    /*if(isTimedOut() ||  targetfound){
    return true;
    }
    return false;*/
    return true;
  }

  // Called once after isFinished returns true
  @Override
  protected void end() {
    //Robot.m_drivetrain.hDriveSpeed(0);
  }

  // Called when another command which requires one or more of the same
  // subsystems is scheduled to run
  @Override
  protected void interrupted() {
    //Robot.m_drivetrain.hDriveSpeed(0);
  }
}
