/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
import frc.robot.Robot;

public class TurnByAngle extends Command {

  double turnBy;
  double speed;
  double startAngle;
  boolean quickTurn;
  int counter = 0;
  final double TURNERROR=1;
  double multiplyer;
  public TurnByAngle(Double angle, Double speed, boolean quickTurn) {
    // Use requires() here to declare subsystem dependencies
    // eg. requires(chassis);
    turnBy = angle;
    this.speed = speed;
    this.quickTurn = quickTurn;
    
  }

  // Called just before this Command runs the first time
  @Override
  protected void initialize() {
    startAngle = Robot.gyro.getAngle();
    multiplyer = 1;
    counter = 0;
  }

  // Called repeatedly when this Command is scheduled to run
  @Override
  protected void execute() {
    if (quickTurn == true){
      if (turnBy<0){
        Robot.m_drivetrain.drive(-1.0*speed*multiplyer, speed*multiplyer);
      }else if(turnBy>0){
        Robot.m_drivetrain.drive(speed*multiplyer, -1.0*speed*multiplyer);
      }
    }else{
      if (Robot.gyro.getAngle()-startAngle>turnBy){
        Robot.m_drivetrain.drive(-1.0*speed*multiplyer, speed*multiplyer);
      }else if(Robot.gyro.getAngle()-startAngle<turnBy){
        Robot.m_drivetrain.drive(speed*multiplyer, -1.0*speed*multiplyer);
        }
      }
    }

  // Make this return true when this Command no longer needs to run execute()
  @Override
  protected boolean isFinished() {
    if (quickTurn == true){
      if(Robot.gyro.getAngle()-startAngle>turnBy){
        return true;
      }else{
        return false;
      }
    }else{
      if(Math.abs((Robot.gyro.getAngle()-startAngle)-turnBy)<TURNERROR){
        counter++;
          if (counter>5){
            System.out.println("done");
            return true;
          }
          /*else if(counter==1){
            //multiplyer = multiplyer*0.5;
            return false;
          }*/
          else{
            multiplyer = multiplyer*0.9;
            return false;
          }
      }else if(Math.abs((Robot.gyro.getAngle()-startAngle)-turnBy)<15 && counter == 0){
        multiplyer = 0.65;
        return false;
      }else{
          return false;
      }
    }
    
  }

  // Called once after isFinished returns true
  @Override
  protected void end() {
    Robot.m_drivetrain.drive(0);
  }

  // Called when another command which requires one or more of the same
  // subsystems is scheduled to run
  @Override
  protected void interrupted() {
    Robot.m_drivetrain.drive(0);
  }
}
