package frc.robot.commands;

import frc.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class TurnToHeading extends Command {

	double maxSpeed=.5;
  	double speed=.5;
	double minSpeedCurrent = .37;
	double lastAngleReading = -4207;
	double startTime;
	double angleReading;
	double targetHeading;
	double startAngle;
    int correctCount = 0;
    boolean quickTurn = false;
    double initialTurnDirection = 1;
    
	
	
	
    public TurnToHeading(double heading, double maxSpeed,boolean quickTurn) {
    	//requires(Robot.sensors);
    	requires(Robot.m_drivetrain);
    	
    	this.maxSpeed = Math.abs(maxSpeed);
    	this.targetHeading = heading;
    	this.quickTurn = quickTurn;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
		angleReading = 0;//startAngle;
	   	startAngle = Robot.autoStartAngle;

//	   	SmartDashboard.putString("Gyro Angle","before "+startAngle);
		angleReading = Robot.gyro.getAngleRelativeTo(startAngle);
		initialTurnDirection = angleReading > 0 ? -1 : 1;

//		SmartDashboard.putString("Gyro Angle Start"," "+angleReading);
//		SmartDashboard.putString("Gyro Angle End"," ");
		startTime = System.currentTimeMillis();
		setTimeout(3.5);
		correctCount = 0;
	    overshot = false;
	}

    // Called repeatedly when this Command is scheduled to run
    boolean overshot;
    protected void execute() {
    	angleReading = Robot.gyro.getAngleRelativeTo(startAngle);
		double angleDifference = targetHeading-angleReading;
		System.out.println("angle " + targetHeading);
		System.out.println("reading" + angleReading);
		if (angleDifference>180){
			angleDifference-=360;
		}else if(angleDifference<-180){
			angleDifference+=360;
		}
    	double angleAbsDifference = Math.abs(angleDifference);
    	double signDifference = angleDifference > 0 ? 1 : -1;

//		SmartDashboard.putNumber("Gyro Angle Read",angleReading);
//		SmartDashboard.putNumber("Gyro Angle dIFF",angleDifference);
//		SmartDashboard.putString("overShot",overshot ? " over" : "no");

    	if(angleDifference*initialTurnDirection > 0) {
    		overshot = true;
    	}
			if(angleAbsDifference > 29.0) {
				speed = maxSpeed;
				correctCount=0;
			} else if(angleAbsDifference > 15.0) {
				speed = (maxSpeed + minSpeedCurrent)/2;
				correctCount=0;
			} else if(angleAbsDifference <2) {
				if(quickTurn) {
					correctCount+= 100;
					speed=0;
				} else {
					correctCount++;
					if(!overshot) {
						speed = -maxSpeed;
					} else {
						speed = 0;
					}
				}
			} else {
				correctCount=0;
				speed = minSpeedCurrent;// + angleAbsDifference/350;
				//if(speed > maxSpeed) speed = maxSpeed;
				if(lastAngleReading != -4207 && Math.abs(angleReading - lastAngleReading) < .005) {
					minSpeedCurrent += .005;
				}
			}
			speed *= signDifference;
//		SmartDashboard.putString("Speed B"," "+speed);
		Robot.m_drivetrain.m_drive.tankDrive(speed,-speed);

		lastAngleReading = angleReading;
		SmartDashboard.putString("min Speed","A " + minSpeedCurrent);
    }
    
    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {   	
//		SmartDashboard.putString("currentAngle"," "+ angleReading + " Count:" + correctCount);
    	return isTimedOut() || (correctCount > 10 ? true :false);
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.m_drivetrain.m_drive.curvatureDrive(0, 0, false);
    	angleReading = Robot.gyro.getAngleRelativeTo(startAngle);
//		SmartDashboard.putString("Turn Finish","finished correct" + angleReading + " in " + (System.currentTimeMillis() - startTime) + "ms min=" + minSpeedCurrent);
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
      	Robot.m_drivetrain.m_drive.curvatureDrive(0, 0, false);
    	angleReading = Robot.gyro.getAngleRelativeTo(startAngle);
//		SmartDashboard.putString("Turn Finish","finished time" + angleReading);
    }
}
