/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
//import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.OI;
import frc.robot.commands.ElevatorDown;
import frc.robot.commands.ElevatorUp;
import frc.robot.commands.HDriveVisionSide;
import frc.robot.commands.HatchInOutToggle;
import frc.robot.commands.HatchUpDownToggle;
import frc.robot.HF2017Utility.HFJoystickPOVButton;
import frc.robot.commands.IntakeDown;
import frc.robot.commands.IntakeIn;
import frc.robot.commands.IntakeUp;
import frc.robot.commands.RobotBackPistonToggle;
import frc.robot.commands.RobotBothPistonToggle;
import frc.robot.commands.SetLEDOn;
import frc.robot.commands.SetLEDToggle;
import frc.robot.commands.TurnToHeading;
import frc.robot.commands.IntakeOut;
import frc.robot.HF2017Utility.HFJoystickTrigger;

import frc.robot.commands.FrontAndBackPiston;
import frc.robot.commands.RobotDownBackPiston;
import frc.robot.commands.RobotDownFrontPiston;
import frc.robot.commands.RobotFrontPistonToggle;
import frc.robot.commands.RobotUpBackPiston;
import frc.robot.commands.RobotUpFrontPiston;
import frc.robot.commands.CompressorToggle;
import frc.robot.commands.CameraToggle;
import frc.robot.commands.CompressorSwitch;
import frc.robot.commands.HDriveVisionSide;
import frc.robot.commands.IntakeGrab;
import frc.robot.commands.IntakeRelease;
import frc.robot.commands.DriveSwitch;


/**
 * This class is the glue that binds the controls on the physical operator
 * interface to the commands and command groups that allow control of the robot.
 */
public class OI {
  //Motors
    //public static final int MOTORHDRIVE2 = 9;
    //public static final int  MOTORHDRIVE = 11;

    public static final boolean isMonaLisa = true;
    public static final int MOTORDRIVELEFTFRONT= 6;
    public static final int  MOTORDRIVELEFTBACK=8;

    public static final int  MOTORSDRIVERIGHTFRONT = 3;
    public static final int MOTORDRIVERIGHTBACK = 2;

    public static final int MOTORELEVATOR2 = 5;
    public static final int MOTORELEVATOR = 12;


    public static final int MOTORINTAKETILT = 10;
    public static final int MOTORINTAKEFEED = 4;
  //  public static final int MOTOR_LEDRING = 8;
    public static final int LIFTDRIVEMOTOR = 7;
    // end mona lisa

/*    public static final boolean isMonaLisa = false;
    public static final int MOTORDRIVELEFTFRONT= 1;
    public static final int  MOTORDRIVELEFTBACK= 7;

    public static final int  MOTORSDRIVERIGHTFRONT = 11;
    public static final int MOTORDRIVERIGHTBACK = 13;
    public static final int MOTORELEVATOR2 = 10;
    public static final int MOTORELEVATOR = 31;


    public static final int MOTORINTAKETILT = 9;
    public static final int MOTORINTAKEFEED = 3;
 //   public static final int MOTOR_LEDRING = 8;
    public static final int LIFTDRIVEMOTOR = -1;
    // end not mona lisa
*/



      //buttons
    private final int ELEVATORUPTRIGGER = 3;
    private final int ELEVATORDOWNTRIGGER = 2;
    
    public static final int INTAKEUP_POVBUTTON = HFJoystickPOVButton.POV_UP;
    public static final int INTAKEDOWN_POVBUTTON =  HFJoystickPOVButton.POV_DOWN;

    public static final int HATCHDEPLOYTOGGLE_BUTTON = 7;
    public static final int HATCHGRABTOGGLE_BUTTON = 8;

    public static final int INTAKEINBUTTON = 6;
    public static final int INTAKEOUTBUTTON = 5;

    public static final int INTAKEGRABBUTTON = 4;
    public static final int INTAKERELEASEBUTTON = 1;

    public static final int DRIVESWITCHBUTTON = 3;   

      //buttons joystick 2

    public static final int HDRIVEVISIONHORIZONTALALIGNAXIS = 2;

    private final int PISTONTOGGLEFRONTBUTTON = 1;
    private final int PISTONTOGGLEBACKBUTTON = 4;
    private final int PISTONTOGGLEFRONTBACKBUTTON = 3;

    public static final int CAMERASWITCH = 2;
   
    private final int COMPRESSORONOFF = HFJoystickPOVButton.POV_LEFT;
    //private final int LEDONOFF = HFJoystickPOVButton.POV_RIGHT;
   
    public static final int INTAKEUP2BUTTON = 6;
    public static final int INTAKEDOWN2BUTTON =  5;


    private final Joystick m_joystick = new Joystick(0);
    private final Joystick m_joystick2 = new Joystick(1); 

    

    

  /**
   * Construct the OI and all of the buttons on it.
   */
  public OI() {
//System.out.println("got here!!!!!");  
    // Put Some buttons on the SmartDashboard
    new HFJoystickTrigger(m_joystick,ELEVATORDOWNTRIGGER).whileHeld(new ElevatorDown());
    new HFJoystickTrigger(m_joystick,ELEVATORUPTRIGGER).whileHeld(new ElevatorUp());
    new HFJoystickTrigger(m_joystick2,ELEVATORDOWNTRIGGER).whileHeld(new ElevatorDown());
    new HFJoystickTrigger(m_joystick2,ELEVATORUPTRIGGER).whileHeld(new ElevatorUp());
    // Create some buttons
    
    new JoystickButton(m_joystick,INTAKEINBUTTON).whileHeld(new IntakeIn());
    new JoystickButton(m_joystick,INTAKEOUTBUTTON).whileHeld(new IntakeOut());
    new HFJoystickPOVButton(m_joystick,INTAKEUP_POVBUTTON).whileHeld(new IntakeUp());
    new HFJoystickPOVButton(m_joystick,INTAKEDOWN_POVBUTTON).whileHeld(new IntakeDown());

    new JoystickButton(m_joystick,HATCHDEPLOYTOGGLE_BUTTON).whenPressed(new HatchInOutToggle());
    new JoystickButton(m_joystick,HATCHGRABTOGGLE_BUTTON).whenPressed(new HatchUpDownToggle());
    

    new HFJoystickPOVButton(m_joystick2, HFJoystickPOVButton.POV_RIGHT).whileHeld(new TurnToHeading(90,.7,false));
    new HFJoystickPOVButton(m_joystick2, HFJoystickPOVButton.POV_DOWN).whileHeld(new TurnToHeading(180,.7,false));
    new HFJoystickPOVButton(m_joystick2, HFJoystickPOVButton.POV_LEFT).whileHeld(new TurnToHeading(-90,.7,false));
    new HFJoystickPOVButton(m_joystick2, HFJoystickPOVButton.POV_UP).whileHeld(new TurnToHeading(0,.7,false));

    new JoystickButton(m_joystick, INTAKEGRABBUTTON).whenPressed(new IntakeGrab());
    new JoystickButton(m_joystick, INTAKERELEASEBUTTON).whenPressed(new IntakeRelease());
    new JoystickButton(m_joystick, DRIVESWITCHBUTTON).whenPressed( new DriveSwitch());

    //new JoystickButton(m_joystick,INTAKEUPBUTTON).whileHeld(new IntakeUp());
    //new JoystickButton(m_joystick,INTAKEDOWNBUTTON).whileHeld(new IntakeDown());

   // new JoystickButton(m_joystick, HDRIVEVISIONHORIZONTALALIGNAXIS).whileHeld(new HDriveVisionSide(1500));
   // new JoystickButton(m_joystick2, HDRIVEVISIONHORIZONTALALIGNAXIS).whileHeld(new HDriveVisionSide(1500));
    
/*    final JoystickButton dpadUp = new JoystickButton(m_joystick, );
    final JoystickButton dpadRight = new JoystickButton(m_joystick, 6);
    final JoystickButton dpadDown = new JoystickButton(m_joystick, 7);
    final JoystickButton dpadLeft = new JoystickButton(m_joystick, 8);
    final JoystickButton l2 = new JoystickButton(m_joystick, 9);
    final JoystickButton r2 = new JoystickButton(m_joystick, 10);
    final JoystickButton l1 = new JoystickButton(m_joystick, 11);
    final JoystickButton r1 = new JoystickButton(m_joystick, 12);
*/
    // Connect the buttons to commands

    new JoystickButton(m_joystick2,INTAKEUP2BUTTON).whileHeld(new IntakeUp());
		new JoystickButton(m_joystick2,INTAKEDOWN2BUTTON).whileHeld(new IntakeDown());
   // new HFJoystickPOVButton(m_joystick,HFJoystickPOVButton.POV_UP).whileHeld(new SetLEDOn(true));
  //new HFJoystickPOVButton(m_joystick,HFJoystickPOVButton.POV_DOWN).whileHeld(new SetLEDOn(false));
//		new HFJoystickPOVButton(m_joystick,HFJoystickPOVButton.POV_DOWN).whileHeld(new IntakeDown());

if(isMonaLisa) {
    new JoystickButton(m_joystick2,PISTONTOGGLEFRONTBUTTON).whenPressed(new RobotFrontPistonToggle());
    new JoystickButton(m_joystick2,PISTONTOGGLEBACKBUTTON).whenPressed(new RobotBackPistonToggle());
    new JoystickButton(m_joystick2,PISTONTOGGLEFRONTBACKBUTTON).whenPressed(new RobotBothPistonToggle());
  }
    new HFJoystickPOVButton(m_joystick,HFJoystickPOVButton.POV_LEFT).whenPressed(new CompressorToggle());
//    new HFJoystickPOVButton(m_joystick,HFJoystickPOVButton.POV_RIGHT).whenPressed(new SetLEDToggle());
    //new JoystickButton(m_joystick,COMPRESSORONOFF).whenPressed(new CompressorToggle());
    //new JoystickButton(m_joystick,LEDONOFF).whenPressed(new SetLEDToggle());
    new JoystickButton(m_joystick2,CAMERASWITCH).whenPressed(new CameraToggle());

  

  }

  public Joystick getJoystick() {
    return m_joystick;
  }
  public Joystick getJoysticktwo() {
    return m_joystick2;
  }
}
