package frc.robot.HF2017Utility;

import edu.wpi.cscore.MjpegServer;
//import edu.wpi.cscore.CameraServerJNI;
//import edu.wpi.cscore.CvSink;
import edu.wpi.cscore.UsbCamera;
import edu.wpi.cscore.VideoSink;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.cameraserver.*;
import edu.wpi.first.wpilibj.networktables.NetworkTable;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

import edu.wpi.cscore.VideoSource;
public class HFCameraPairSwitchable2019b {
	
	VideoSink server;
	int curCamera = 0;
	public static UsbCamera[] camera;
	int numCameras;
	public HFCameraPairSwitchable2019b(int numCameras) {
		this.numCameras = numCameras;
		CameraServer cs = CameraServer.getInstance();
		camera = new UsbCamera[numCameras];
		
		for(int i=0;i<numCameras;i++) {
			camera[i] = cs.startAutomaticCapture("cam" + i,i);
			camera[i].setResolution(160, 120);
			
			camera[i].setConnectionStrategy(VideoSource.ConnectionStrategy.kKeepOpen);
		}
		server = cs.addSwitchedCamera("drivercams");
		server.setSource(camera[0]);
//		camera1 = new UsbCamera("cam0",0);
 //    	camera2 = new UsbCamera("cam1",1);
/*    	CvSink cvSink1 = new CvSink("csCamera1");
    	cvSink1.setSource(camera1);
    	cvSink1.setEnabled(true);

    	CvSink cvSink2 = new CvSink("csCamera2");
    	cvSink2.setSource(camera2);
    	cvSink2.setEnabled(true);
*/
    	setCamera(1);
    	
	}
	
	@SuppressWarnings("deprecation")
	public void setCamera(int camIndex) {
//		if(camIndex > numCameras-1) camIndex = 0;
		server.setSource(camera[camIndex]);
		SmartDashboard.putString("Camera","cam " + camIndex);
		NetworkTable.getTable("").putString("CameraSelection", camera[camIndex].getName());
		curCamera = camIndex;
	}
	public void nextCamera(){
		setCamera((curCamera+1)%numCameras);
	}
}
