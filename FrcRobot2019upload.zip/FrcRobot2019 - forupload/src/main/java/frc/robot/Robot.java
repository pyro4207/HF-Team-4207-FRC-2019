/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot;

//import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;


import frc.robot.subsystems.DriveTrain;
import frc.robot.subsystems.ElevatorUpAndDown;
import frc.robot.subsystems.HatchPanel;
import frc.robot.subsystems.Intake;
import frc.robot.subsystems.LiftingMechanisim;
import frc.robot.subsystems.Locator;
import frc.robot.subsystems.PistonMotor;
import frc.robot.subsystems.VisionSystem;
import frc.robot.HF2017Utility.HFCameraPairSwitchable2018;
import frc.robot.HF2017Utility.NavXGyro;
import frc.robot.autonomous.ClassTest;
import frc.robot.autonomous.JeremyAuto;
import frc.robot.commands.*; 

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends TimedRobot {
  

  public static ElevatorUpAndDown m_elevatorupanddown;
  public static DriveTrain m_drivetrain;
  public static OI m_oi;
  public static Intake m_intake;
  public static VisionSystem m_visionSystem;
  public static Locator locator;
  public static PistonMotor m_pistonmotor;
  public static HatchPanel m_hatchpanel;

  public static LiftingMechanisim m_liftingMechanisim;
  public static Compressor airCompressor;
//  public static HFCameraPairSwitchable2018 cameraSwitch;

  public static DifferentialDrive m_drive;
  public static NavXGyro gyro;
  Command m_autonomousCommand;
  SendableChooser<Command> m_chooser = new SendableChooser<>();
  public static double autoStartAngle = 0;

  /**
   * This function is run when the robot is first started up and should be
   * used for any initialization code.
   */
 
  @Override
  public void robotInit() {
    // Initialize all subsystems
    m_elevatorupanddown = new ElevatorUpAndDown();
    m_drivetrain = new DriveTrain();

    m_hatchpanel = new HatchPanel();
    
    m_oi = new OI();
    System.out.println("hello");
    m_autonomousCommand = new JeremyAuto();
    m_intake = new Intake();
    m_visionSystem = new VisionSystem(2);
    locator = new Locator("vision",0,0);
    if(OI.isMonaLisa) {
      m_pistonmotor = new PistonMotor();
      m_liftingMechanisim = new LiftingMechanisim();
      
    }
    gyro = new NavXGyro();
  //  cameraSwitch = new HFCameraPairSwitchable2018();
   // CameraServer.getInstance().startAutomaticCapture();
   
    // Show what command your subsystem is running on the SmartDashboard
    SmartDashboard.putData(m_drivetrain);

    m_chooser.setDefaultOption("Default Auto", new DoNothing());
    // chooser.addOption("My Auto", new MyAutoCommand());
    SmartDashboard.putData("Auto mode", m_chooser);
    airCompressor = new Compressor();
   if(OI.isMonaLisa)  {
      m_liftingMechanisim.RobotDownfront();
      m_liftingMechanisim.RobotDownback();
   }
  }

  @Override
  public void autonomousInit() {
//    m_autonomousCommand.start(); // schedule the autonomous command (example)
    gyro.reset();
    //m_autonomousCommand = m_chooser.getSelected();
   // m_autonomousCommand = new TestAiming();
    m_visionSystem.turnOn();
    airCompressor.start();
    m_intake.grab();
    m_hatchpanel.HatchOut();
    m_hatchpanel.HatchUp();
    if (m_autonomousCommand != null) {
      //System.out.println("before auto");
      m_autonomousCommand.start();
     // System.out.println("after auto");
    }
    if(OI.isMonaLisa) {
        m_liftingMechanisim.RobotDownback();
        m_liftingMechanisim.RobotDownfront();
    }
}

  /**
   * This function is called periodically during autonomous.
   */
  @Override
  public void autonomousPeriodic() {
    Scheduler.getInstance().run();
    log();
  }

  @Override
  public void teleopInit() {
//    gyro.reset();
    // This makes sure that the autonomous stops running when
    // teleop starts running. If you want the autonomous to
    // continue until interrupted by another command, remove
    // this line or comment it out.
    if(m_autonomousCommand != null){
    m_autonomousCommand.cancel();
    }
 //   m_visionSystem.turnOn();
    airCompressor.start();
    m_hatchpanel.HatchUp();
    m_hatchpanel.HatchOut();
  //  m_intake.grab(); /// remove before competition
    if(OI.isMonaLisa) {
      m_liftingMechanisim.RobotDownfront();
      m_liftingMechanisim.RobotDownback();
    }
  }

  /**
   * This function is called periodically during teleoperated mode.
   */
  @Override
  public void teleopPeriodic() {
    Scheduler.getInstance().run();
   // LEDring.set(-1);
    log();
  }

  /**
   * This function is called periodically during test mode.
   */
  @Override
  public void testPeriodic() {
  }

  /**
   * The log method puts interesting information to the SmartDashboard.
   */
  private void log() {
    m_drivetrain.log();
  }

  @Override
  public void disabledPeriodic() {
    Scheduler.getInstance().run();
    if(m_oi.getJoystick().getRawButtonPressed(OI.CAMERASWITCH)) {
      m_visionSystem.nextCamera();
    }
//    m_visionSystem.turnOff();
//    airCompressor.stop();
  }
  @Override
  public void disabledInit() {
    m_visionSystem.turnOff();
    airCompressor.stop();
  }
}
